package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.IEmployeeDao;
@Service
public class EmployeeServiceImpl implements IEmployeeService {
	@Autowired
	IEmployeeDao dao;

	@Override
	public Employee insertEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return dao.insertEmployee(employee);
	}

	@Override
	public List<Employee> viewEmployee() {
		// TODO Auto-generated method stub
		return dao.viewEmployee();
	}

	@Override
	public Employee deleteEmployee(String empId) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(empId);
	}

	@Override
	public Employee updateEmployee(String empId,Employee employee) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(empId,employee);
	}

	@Override
	public String deleteAllEmployee() {
		// TODO Auto-generated method stub
		return dao.deleteAllEmployee();
	}

	@Override
	public Employee viewbyIDEmployee(String empId) {
		// TODO Auto-generated method stub
		return dao.viewbyIDEmployee(empId);
	}

}
