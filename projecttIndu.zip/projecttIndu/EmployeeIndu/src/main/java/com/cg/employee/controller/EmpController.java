package com.cg.employee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.bean.Employee;
import com.cg.employee.service.IEmployeeService;

@RestController
@RequestMapping("/emp")
public class EmpController {
	@Autowired
	IEmployeeService service;
	//EmpRepository repository;
	
	@RequestMapping(value = "/insert")
    public Employee insertEmployee(@Valid @RequestBody Employee employee) {
        return service.insertEmployee(employee);
    }
	@RequestMapping(value = "/view",method = RequestMethod.GET)
	public List<Employee> viewEmployee()
	{
		return service.viewEmployee();
	}
	
	@RequestMapping(value = "/viewbyID/{empId}",method = RequestMethod.GET)
	public Employee viewbyIDEmployee(@PathVariable String empId)
	{
		return service.viewbyIDEmployee(empId);
	}
	@RequestMapping(value = "/delete/{empId}",method = RequestMethod.DELETE)
	public Employee deleteEmployee(@PathVariable String empId)
	{
		return service.deleteEmployee(empId);
	}
	@RequestMapping(value = "/deleteall",method = RequestMethod.DELETE)
	
	public String deleteAllEmployee()
	{
		return service.deleteAllEmployee();
	}
	
	
	@RequestMapping(value = "/update/{empId}",method = RequestMethod.PUT)
	public Employee updateEmployee(@PathVariable String empId,@RequestBody Employee employee)
	{
		return service.updateEmployee(empId,employee);
	}

}
