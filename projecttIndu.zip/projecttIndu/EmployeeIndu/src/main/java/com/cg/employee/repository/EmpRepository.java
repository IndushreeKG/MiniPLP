package com.cg.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.employee.bean.Employee;

public interface EmpRepository extends JpaRepository<Employee, String> {
	
	

	
}
