package com.cg.expenseclaimdetailsmodule.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.expenseclaimdetailsmodule.bean.Employee;
import com.cg.expenseclaimdetailsmodule.bean.ExpenseModule;
import com.cg.expenseclaimdetailsmodule.bean.ProjectBean;

@RestController
public class ExpenseClaimController {
	/*@RequestMapping(value = "/createData", method = RequestMethod.POST)
	@ResponseBody
	public Employee createEmployeeData(@RequestBody Employee Employee) {
		final String uri = "http://localhost:8888/emp/insert"; 
	    RestTemplate restTemplate = new RestTemplate();
	    Employee result = restTemplate.postForObject( uri, Employee, Employee.class);
	    System.out.println(result);
	    return result;
	}*/
	
	@RequestMapping(value = "/readData", method = RequestMethod.GET)
	@ResponseBody
	public List<Employee> readEmployeeData() {
		final String uri = "http://localhost:8888/emp/view"; 
	    RestTemplate restTemplate = new RestTemplate();
	    List<Employee> result = restTemplate.getForObject(uri, List.class);
	    return result;
	}

	@RequestMapping(value = "/read/{empId}", method = RequestMethod.GET)
	@ResponseBody
	public Employee viewbyIDEmployee(@PathVariable String empId) {
		final String uri = "http://localhost:8888/emp/viewbyID/{empId}"; 
	    RestTemplate restTemplate = new RestTemplate();
	    Employee result = restTemplate.getForObject(uri, Employee.class,empId);
	    return result;
	}
	

	@RequestMapping(value = "/readproject/{projectCode}", method = RequestMethod.GET)
	@ResponseBody
	public ProjectBean viewbyprojectCode(@PathVariable String projectCode) {
		final String uri = "http://localhost:7777/project/viewByCode/{projectCode}"; 
	    RestTemplate restTemplate = new RestTemplate();
	    ProjectBean result =  restTemplate.getForObject(uri, ProjectBean.class,projectCode);
	    return result;
	}
	@RequestMapping(value = "/readexpense/{expenseCode}", method = RequestMethod.GET)
	@ResponseBody
	public ExpenseModule viewbyexpenseCode(@PathVariable String expenseCode) {
		final String uri = "http://localhost:8888/emp/readById/{expenseCode}"; 
	    RestTemplate restTemplate = new RestTemplate();
	    ExpenseModule result =  restTemplate.getForObject(uri, ExpenseModule.class,expenseCode);
	    return result;
	}
	
	@RequestMapping(value = "/updateExpense/{expenseCode}", method = RequestMethod.PUT)
	@ResponseBody
	public String updateExpenseCode(@PathVariable String expenseCode,@RequestBody ExpenseModule expenseModule) {
		final String uri = "http://localhost:8888/emp/update/{expenseCode}"; 
	    RestTemplate restTemplate = new RestTemplate();
	    restTemplate.put(uri, expenseModule, expenseCode);
	     return "updated";
	    
	}
	
	@RequestMapping(value = "/deleteExpense/{expenseCode}", method = RequestMethod.DELETE)
	@ResponseBody
	public String deleteExpenseCode(@PathVariable String expenseCode) {
		final String uri = "http://localhost:8888/emp/delete/{expenseCode}"; 
	    RestTemplate restTemplate = new RestTemplate();
	     restTemplate.delete(uri, expenseCode);
	     return "Deleted";
	    
	}
	
}
