package com.cg.projectcodemodule.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.projectcodemodule.bean.ProjectBean;
import com.cg.projectcodemodule.service.IProjectService;
@RestController
@RequestMapping("/project")
public class ProjectController {
	
	@Autowired
	IProjectService service;
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public ProjectBean insertProjectDetails(@RequestBody ProjectBean projectBean)
	{
		return service.insertProjectDetails(projectBean);
	}
	
	@RequestMapping(value="/view",method=RequestMethod.GET)
	public List<ProjectBean> viewProjectDetails()
	{
		return service.viewProjectDetails();
	}
	
	@RequestMapping(value="/viewByCode/{projectCode}",method=RequestMethod.GET)
	public ProjectBean viewProjectDetailsByCode(@PathVariable String projectCode)
	{
		return service.viewProjectDetailsByCode(projectCode);
	}
	
	@RequestMapping(value="/deleteByCode/{projectCode}",method=RequestMethod.DELETE)
	public ProjectBean deleteProjectDetailsByCode(@PathVariable String projectCode)
	{
		return service.deleteProjectDetailsByCode(projectCode);
	}
	
	@RequestMapping(value="/update/{projectCode}",method=RequestMethod.PUT)
	public ProjectBean updateProjectDetails(@PathVariable String projectCode,@RequestBody ProjectBean projectBean )
	{
		return service.updateProjectDetails(projectCode,projectBean);
	}

}
