package com.cg.projectcodemodule.service;

import java.util.List;

import com.cg.projectcodemodule.bean.ProjectBean;

public interface IProjectService {

	ProjectBean insertProjectDetails(ProjectBean projectBean);

	List<ProjectBean> viewProjectDetails();

	ProjectBean viewProjectDetailsByCode(String projectCode);

	ProjectBean deleteProjectDetailsByCode(String projectCode);

	ProjectBean updateProjectDetails(String projectCode, ProjectBean projectBean);

}
